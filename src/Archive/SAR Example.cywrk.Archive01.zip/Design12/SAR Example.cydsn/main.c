/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <math.h> 


 float voltage = 0; 
 uint16 counts = 0; 

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    ADC_Start(); 
    UART_1_Start();
    char outputstring[50]; 
 

    

    for(;;)
    {
        ADC_StartConvert(); 
        
        counts = ADC_GetResult16(); 
        
        voltage = ADC_CountsTo_Volts(counts); 
        if (voltage >= 1.3) 
        { 
          Pin_2_Write(1); 
        }
        else 
        { 
          Pin_2_Write(0); 
        } 
        
        sprintf(outputstring, "%6.3f", voltage); 
        
        UART_1_PutString(outputstring);  
        UART_1_PutString("\r\n"); 
        
       
        CyDelay(300);        
        
    }
}



/* [] END OF FILE */
